from django.shortcuts import render, redirect

# Create your views here.
def index(request):
    pass


def new(request):
    pass


def create(request):
    pass


def detail(request, pk):
    pass


def delete(request, pk):
    pass


def edit(request, pk):
    pass


def update(request, pk):
    pass
